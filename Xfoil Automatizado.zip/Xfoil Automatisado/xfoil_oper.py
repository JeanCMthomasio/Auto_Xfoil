import numpy as np
import os
import subprocess as sp
import re
from matplotlib import pyplot as plt

#Função que ativa a rotina de comando do Xfoil
def Xfoil(parameters: list, p_err: bool= True, p_out: bool= True) -> None:
    #Caminho para o Xfoil
    path = os.path.join(os.getcwd(),r"Xfoil\xfoil.exe")

    #Checa se a lista tem apenas strings
    try:
        all(isinstance(n, str) for n in parameters)
    except:
        print("A lista deve conter apenas 'strings'")
        return

    #Desempacota lista de parametros
    name, rey, mach, alphai, alphaf, step = parameters

    #Lista de comandos
    cmdlst=[f"load",
            f"{name}",  #Nome deve incluir terminação .dat/.txt
            f"{name[:-4]}",
            'OPER',         #Entra no menu OPER
                'ITER',     #Altera o numero de iteração máximas
                    '150',
                'v',        #Edita o numero de reynolds
                    rey,
                'm',        #Edita o numero de mach
                    mach,
                'PACC',
                    f'{name[:-4]}_polar.txt', #Cria arquivo de output com o nome da rodada
                    ' ',    #Sem arquivo Dump
                'aseq',     #Inicia a rodada
                    alphai,
                    alphaf,
                    step,
                'p',
                '',
                'quit']

    #Salva o diretório base
    base_dir = os.getcwd()

    #Muda para o diretório do xfoil
    os.chdir(path[:-10])

    #Roda o Xfoil
    with sp.Popen(path, stdin=sp.PIPE, stdout=sp.PIPE, stderr=sp.PIPE) as ps:
        #Itera pela lista de comandos e envia para o Xfoil
        err,out = ps.communicate("\n".join(cmdlst).encode())
        #Seletor de retorno
        if p_err == True:
            print(f"err= {err.decode()}")
        if p_out == True:
            print(f"out= {out.decode()}")

    #Retorna ao diretório
    os.chdir(base_dir)

#Função para execução em sequência
def batch_execute(settings_file: str) -> None:

    #Cria os diretórios apropriados e garante a existencia do arquivo de configurações
    lstdir = os.listdir()
    if "Airfoils" not in lstdir:
        os.mkdir("Airfoils")
    if "Polars" not in lstdir:
        os.mkdir("Polars")
    if settings_file not in lstdir:
        print("Arquivo de configurações não encontrado no diretório, arquivo exemplo gerado")
        with open("settings.txt",'w') as f:
            f.write("nome, reynolds, mach, a0 , af, step \nnome2, reynolds2, mach2, a0 , af, step")
        return

    #Extrai as configurações do arquivo
    with open(settings_file,'r') as f:
        settings = [i.strip("\n").split(', ') for i in f]

    #Lista o diretório de aerofólios
    lstdir = os.listdir(os.path.join(os.getcwd(),"Airfoils"))

    #Itera na execução dos aerofólios
    for parameters in settings:
        #par[0] é o nome do aerofólio
        if parameters[0] in lstdir:
            #Muda o perfil para a pasta do Xfoil
            os.rename(os.path.join(os.getcwd(),"Airfoils",parameters[0]), os.path.join(os.getcwd(),'Xfoil',parameters[0]))
            #Executa o Xfoil
            Xfoil(parameters, False, False)
            #Retorna o perfil para a pasta Airfoils
            os.rename(os.path.join(os.getcwd(),'Xfoil',parameters[0]), os.path.join(os.getcwd(),"Airfoils",parameters[0]))

    #Lista diretório do Xfoil
    lstdir = os.listdir(os.path.join(os.getcwd(),"Xfoil"))

    #Transfere as polares para a pasta Polars
    for file in lstdir:
        #Procura a palavra polar no nome do arquivo
        if re.search("^.+polar.+$",file):
            os.rename(os.path.join(os.getcwd(),'Xfoil',file), os.path.join(os.getcwd(),"Polars",file))

#Retorna dados das polares em um dicionario de arrays
def polar_data() -> dict:
    #Lista os arquivos do diretório de polares
    os.chdir(os.path.join(os.getcwd(),"Polars"))
    lstdir = os.listdir()

    #Cria o dicionario com os dados
    data = {}

    #Lê as polares e salva as polares
    for file in lstdir:
        polar = np.loadtxt(file, skiprows= 12)
        data[file[:-4]] = np.transpose(polar)

    return data

#Execução para um aerofólio (que deve estar na pasta do Xfoil ou ter o nome dos seu path completo)
#par = ["naca2224.dat", "1500000", '0.1', '0' , '10' , '1']
#Xfoil(par)

#Execução para uma lista de aerofólios
#batch_execute("settings.csv")

#Análise das polares
#data = polar_data()
#print(data)
